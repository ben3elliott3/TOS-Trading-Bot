import os
import requests
import time
import re
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Discord credentials
DISCORD_USER_TOKEN = os.getenv("DISCORD_USER_TOKEN")
DISCORD_CHANNEL_ID = os.getenv("DISCORD_CHANNEL_ID")

# Discord API headers
HEADERS = {
    "Authorization": DISCORD_USER_TOKEN,
    "Content-Type": "application/json",
}

# Risk management parameters
ACCOUNT_SIZE = 1000  # Starting account size
POSITION_SIZE_PERCENTAGE = 0.3  # 30% of account size per trade
MAX_RISK_PERCENTAGE = 0.3  # 30% risk per trade
DAILY_MAX_DRAWDOWN = 180  # Stop trading if losses exceed this
WEEKLY_MAX_DRAWDOWN = 540  # Stop trading if weekly losses exceed this

POSITION_SIZE = ACCOUNT_SIZE * POSITION_SIZE_PERCENTAGE
MAX_LOSS_PER_TRADE = POSITION_SIZE * MAX_RISK_PERCENTAGE
daily_loss = 0
weekly_loss = 0

def fetch_latest_messages(channel_id, limit=1):
    """Fetch the latest messages from a Discord channel."""
    url = f"https://discord.com/api/v9/channels/{channel_id}/messages?limit={limit}"
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching messages: {response.status_code}")
        return []

def parse_trade_signal(message):
    """Parse trade signals from a Discord message."""
    signal_pattern = r"(Buy|Sell)\s+(\w+)\s+(\d+[CP])\s+(\d{2}/\d{2}/\d{4})\s*\$?(\d+)?"
    match = re.search(signal_pattern, message)
    if match:
        action, ticker, option_type, expiry_date, cost = match.groups()
        return action, ticker, option_type, expiry_date, float(cost) if cost else None
    return None

def select_fallback_option(ticker, current_price):
    """Select a fallback option 1 chain out of the money, 0DTE."""
    strike_price = round(current_price + 1)  # Adjust for 1 chain out-of-the-money
    option_type = "C" if current_price >= strike_price else "P"  # Calls or Puts
    return strike_price, option_type

def place_options_order(symbol, action, quantity, strike, expiry, option_type, price_limit=None):
    """Mocked function to simulate placing an options order."""
    print(f"Placing order: {action} {quantity} contracts of {symbol} "
          f"{strike}{option_type} expiring {expiry} at limit {price_limit if price_limit else 'MARKET'}.")

def manage_trade(position_size, entry_price, current_price, tps_hit):
    """Manage stop loss and take profit levels for a trade."""
    profit = (current_price - entry_price) / entry_price * 100  # % profit

    # Define TPs and stop-loss
    TP1, TP2, TP3 = 30, 50, 100

    if TP1 <= profit < TP2 and "TP1" not in tps_hit:
        tps_hit.append("TP1")
        position_size *= 0.6
        print(f"Take Profit 1 hit. Remaining position: {position_size}")

    elif TP2 <= profit < TP3 and "TP2" not in tps_hit:
        tps_hit.append("TP2")
        position_size *= 0.7
        print(f"Take Profit 2 hit. Moving stop to break-even.")

    elif profit >= TP3 and "TP3" not in tps_hit:
        tps_hit.append("TP3")
        position_size = 0
        print("Take Profit 3 hit. Trade fully closed.")

    elif profit <= -30:
        position_size = 0
        print("Stop Loss hit. Trade closed.")

    return position_size, tps_hit

def check_risk_limits(daily_loss, weekly_loss):
    """Check daily/weekly loss limits."""
    if daily_loss >= DAILY_MAX_DRAWDOWN:
        print("Daily drawdown limit hit. Stopping trading for the day.")
        return True
    if weekly_loss >= WEEKLY_MAX_DRAWDOWN:
        print("Weekly drawdown limit hit. Stopping trading for the week.")
        return True
    return False

def monitor_channel():
    """Monitor Discord channel for new messages and execute trades."""
    global POSITION_SIZE  # Declare global to modify POSITION_SIZE
    last_message_id = None
    tps_hit = []  # Tracks take-profit levels hit for each trade
    active_trade = False  # Tracks if a trade is currently active

    while True:
        messages = fetch_latest_messages(DISCORD_CHANNEL_ID, limit=1)
        if messages:
            message = messages[0]
            if message["id"] != last_message_id:
                last_message_id = message["id"]
                content = message["content"]
                print(f"New message: {content}")

                # Parse signal or use fallback
                trade_signal = parse_trade_signal(content)
                if trade_signal:
                    action, ticker, option_type, expiry_date, cost = trade_signal

                    # If cost is missing, select fallback
                    if not cost:
                        print("Missing cost in signal. Using fallback option selection.")
                        current_price = 400  # Mock price for SPY
                        strike, option_type = select_fallback_option(ticker, current_price)
                        expiry_date = "same-day"
                        cost = 50  # Default $50 cost assumption

                    place_options_order(
                        symbol=ticker,
                        action=action,
                        quantity=1,
                        strike=strike,
                        expiry=expiry_date,
                        option_type=option_type,
                        price_limit=cost
                    )
                    active_trade = True  # Mark trade as active
                    print("Trade executed.")
                else:
                    print("No valid trade signal found.")
            else:
                print("No new message. Skipping.")
        else:
            print("Error fetching messages.")

        # Only manage active trades
        if active_trade:
            # Simulate trade monitoring (replace with actual updates)
            entry_price = 50  # Mock entry price
            current_price = 65  # Mock current price
            POSITION_SIZE, tps_hit = manage_trade(POSITION_SIZE, entry_price, current_price, tps_hit)

            # Stop trade management if position size is zero
            if POSITION_SIZE == 0:
                active_trade = False
                print("Trade management complete. No active trades.")

        # Monitor risk limits
        if check_risk_limits(daily_loss, weekly_loss):
            break

        time.sleep(30)


if __name__ == "__main__":
    print("Monitoring Discord channel for trades...")
    monitor_channel()

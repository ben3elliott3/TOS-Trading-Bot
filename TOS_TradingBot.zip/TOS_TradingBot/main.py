import schwabdev
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Retrieve Schwab credentials from .env
APP_KEY = os.getenv("SCHWAB_APP_KEY")
APP_SECRET = os.getenv("SCHWAB_APP_SECRET")

# Initialize Schwab API client
client = schwabdev.Client(APP_KEY, APP_SECRET)

def main():
    # Step 1: Generate Authorization URL
    auth_url = client.get_authorization_url()
    print("Authorize your app by visiting this URL:")
    print(auth_url)

    # Step 2: Exchange Authorization Code for Tokens
    auth_code = input("Enter the authorization code from the URL: ") #WAITING ON THIS
    tokens = client.get_access_token(auth_code)
    print("Access Token:", tokens['access_token'])
    print("Refresh Token:", tokens['refresh_token'])

    # Save tokens for reuse
    access_token = tokens['access_token']
    refresh_token = tokens['refresh_token']

    # Step 3: Fetch Account Information
    try:
        accounts = client.get('accounts', access_token=access_token)
        print("Account Details:", accounts)
    except Exception as e:
        print(f"Error fetching accounts: {e}")

    # Step 4: Place a Trade
    try:
        order_response = client.place_order(
            account_id='benelliott3ira',  # Replace with actual account ID
            symbol='AAPL',
            quantity=10,
            order_type='market',
            action='buy',
            access_token=access_token
        )
        print("Order Response:", order_response)
    except Exception as e:
        print(f"Error placing order: {e}")

    # Step 5: Refresh Access Token (if needed)
    try:
        refreshed_tokens = client.refresh_access_token(refresh_token)
        print("New Access Token:", refreshed_tokens['access_token'])
    except Exception as e:
        print(f"Error refreshing token: {e}")

if __name__ == "__main__":
    main()


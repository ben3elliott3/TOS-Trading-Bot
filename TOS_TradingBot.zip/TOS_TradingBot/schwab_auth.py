import os
from dotenv import load_dotenv
import requests

# Load environment variables
load_dotenv()

CLIENT_ID = os.getenv("SCHWAB_CLIENT_ID")
CLIENT_SECRET = os.getenv("SCHWAB_CLIENT_SECRET")
REDIRECT_URI = os.getenv("SCHWAB_REDIRECT_URI")
AUTH_URL = os.getenv("SCHWAB_AUTH_URL")
TOKEN_URL = os.getenv("SCHWAB_TOKEN_URL")

def get_authorization_url():
    """Generate the authorization URL for Schwab OAuth."""
    if not CLIENT_ID or not REDIRECT_URI or not AUTH_URL:
        raise ValueError("Missing environment variables. Check your .env file.")
    return f"{AUTH_URL}?response_type=code&client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}"

def get_access_token(auth_code):
    """Exchange authorization code for access and refresh tokens."""
    payload = {
        "grant_type": "authorization_code",
        "code": auth_code,
        "redirect_uri": REDIRECT_URI,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
    }
    response = requests.post(TOKEN_URL, data=payload)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to get access token: {response.status_code}, {response.text}")

if __name__ == "__main__":
    print("Authorize your app by visiting this URL:")
    print(get_authorization_url())
    auth_code = input("Enter the authorization code from the URL: ")
    tokens = get_access_token(auth_code)
    print("Access Token:", tokens.get("access_token"))
    print("Refresh Token:", tokens.get("refresh_token"))
